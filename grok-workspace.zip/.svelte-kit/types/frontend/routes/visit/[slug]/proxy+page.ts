// @ts-nocheck
import { guidesByPillar } from '$lib/data';
import { error } from '@sveltejs/kit';
import type { PageLoad } from './$types';

export function entries() {
	return guidesByPillar('visit').map((guide) => ({ slug: guide.slug }));
}

export const load = ({ params }: Parameters<PageLoad>[0]) => {
	const guide = guidesByPillar('visit').find((item) => item.slug === params.slug);
	if (!guide) error(404, 'Guide not found');
	return { guide };
};
