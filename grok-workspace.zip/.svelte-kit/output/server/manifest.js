export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["cowork.jpg","riverside.jpg"]),
	mimeTypes: {".jpg":"image/jpeg"},
	_: {
		client: {start:"_app/immutable/entry/start.YeSXaPjC.js",app:"_app/immutable/entry/app.BlEQxkP-.js",imports:["_app/immutable/entry/start.YeSXaPjC.js","_app/immutable/chunks/DTLYatpg.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/Dt-HX3Vu.js","_app/immutable/entry/app.BlEQxkP-.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/xihTtKlq.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js'))
		],
		remotes: {
			
		},
		routes: [
			
		],
		prerendered_routes: new Set(["/","/directory","/live","/visit","/live/first-ninety-days","/live/generators-and-neighbourhoods","/visit/five-days-without-logistics","/visit/arriving-with-a-deadline"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
