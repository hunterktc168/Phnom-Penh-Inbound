
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/directory" | "/live" | "/live/[slug]" | "/visit" | "/visit/[slug]";
		RouteParams(): {
			"/live/[slug]": { slug: string };
			"/visit/[slug]": { slug: string }
		};
		LayoutParams(): {
			"/": { slug?: string | undefined };
			"/directory": Record<string, never>;
			"/live": { slug?: string | undefined };
			"/live/[slug]": { slug: string };
			"/visit": { slug?: string | undefined };
			"/visit/[slug]": { slug: string }
		};
		Pathname(): "/" | "/directory" | "/live" | `/live/${string}` & {} | `/live/${string}/` & {} | "/visit" | `/visit/${string}` & {} | `/visit/${string}/` & {};
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/cowork.jpg" | "/riverside.jpg" | string & {};
	}
}