

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.hchr7heD.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/pAoUochj.js","_app/immutable/chunks/DTLYatpg.js","_app/immutable/chunks/Dt-HX3Vu.js","_app/immutable/chunks/BjpwoQae.js"];
export const stylesheets = [];
export const fonts = [];
