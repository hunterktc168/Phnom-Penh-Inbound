import * as universal from "../../../../frontend/routes/visit/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../frontend/routes/visit/[slug]/+page.svelte";