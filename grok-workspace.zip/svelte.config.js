import adapter from '@sveltejs/adapter-static';

/** @type {import('@sveltejs/kit').Config} */
const config = {
	kit: {
		adapter: adapter({
			pages: 'build',
			assets: 'build',
			fallback: '200.html',
			precompress: false,
			strict: true
		}),
		files: {
			assets: 'frontend/static',
			hooks: {
				client: 'frontend/hooks.client',
				server: 'frontend/hooks.server',
				universal: 'frontend/hooks'
			},
			lib: 'frontend/lib',
			params: 'frontend/params',
			routes: 'frontend/routes',
			serviceWorker: 'frontend/service-worker',
			appTemplate: 'frontend/app.html',
			errorTemplate: 'frontend/error.html'
		},
		prerender: {
			handleMissingId: 'warn',
			handleHttpError: 'warn'
		}
	}
};

export default config;
