export type Pillar = 'visit' | 'live';
export type VenueCategory = 'coworking' | 'clinic' | 'apartment' | 'cafe' | 'visa_agent';

export type Location = {
	slug: string;
	name: string;
	level: 'sangkat';
	parentRegion: string;
	vibe: string;
	rent1br: number;
	walkability: number;
	summary: string;
};

export type Venue = {
	slug: string;
	name: string;
	category: VenueCategory;
	locationSlug: string;
	wifiMbps: number | null;
	hasGenerator: boolean;
	priceTier: 1 | 2 | 3 | 4;
	verifiedOn: string;
	completeness: number;
	blurb: string;
	photo: 'riverside' | 'cowork' | 'none';
};

export type Guide = {
	slug: string;
	pillar: Pillar;
	title: string;
	dek: string;
	author: string;
	reviewed: string;
	minutes: number;
	sections: { heading: string; body: string[] }[];
};

export const CATEGORIES: { id: VenueCategory | 'all'; label: string }[] = [
	{ id: 'all', label: 'All' },
	{ id: 'coworking', label: 'Coworking' },
	{ id: 'cafe', label: 'Cafés' },
	{ id: 'clinic', label: 'Clinics' },
	{ id: 'apartment', label: 'Apartments' },
	{ id: 'visa_agent', label: 'Visa agents' }
];

export const locations: Location[] = [
	{
		slug: 'bkk1',
		name: 'BKK1',
		level: 'sangkat',
		parentRegion: 'Phnom Penh',
		vibe: 'Walkable, dense, the default first address',
		rent1br: 650,
		walkability: 82,
		summary:
			'The usual landing neighbourhood. Cafés, clinics, and coworking sit within a few blocks, and one-bedroom rents cluster around the mid-six hundreds when the building has a generator.'
	},
	{
		slug: 'toul-tom-poung',
		name: 'Toul Tom Poung',
		level: 'sangkat',
		parentRegion: 'Phnom Penh',
		vibe: 'Quieter streets, Russian Market at the edge',
		rent1br: 520,
		walkability: 74,
		summary:
			'A step down in rent from BKK1 with most daily needs still on foot. Power cuts are less predictable on the side streets; ask about the generator before you sign.'
	},
	{
		slug: 'daun-penh',
		name: 'Daun Penh',
		level: 'sangkat',
		parentRegion: 'Phnom Penh',
		vibe: 'Riverside, older shophouses, more visitors',
		rent1br: 580,
		walkability: 78,
		summary:
			'The riverfront and the administrative core. Useful if you want to be near the palace-side clinics and visa offices, noisier in the evening along the quay.'
	},
	{
		slug: 'chroy-changvar',
		name: 'Chroy Changvar',
		level: 'sangkat',
		parentRegion: 'Phnom Penh',
		vibe: 'Newer towers across the bridge',
		rent1br: 700,
		walkability: 46,
		summary:
			'Larger apartments and more reliable building power, at the cost of a bridge crossing for almost everything. Treat walkability scores here as building-to-building, not neighbourhood-wide.'
	}
];

export const venues: Venue[] = [
	{
		slug: 'pavilion-work',
		name: 'Pavilion Work',
		category: 'coworking',
		locationSlug: 'bkk1',
		wifiMbps: 180,
		hasGenerator: true,
		priceTier: 3,
		verifiedOn: '2026-10-02',
		completeness: 90,
		blurb: 'Day passes and monthly desks. Generator covers the work floor; measured download was 180 Mbps on the last check.',
		photo: 'cowork'
	},
	{
		slug: 'lane-house',
		name: 'Lane House',
		category: 'cafe',
		locationSlug: 'bkk1',
		wifiMbps: 70,
		hasGenerator: false,
		priceTier: 2,
		verifiedOn: '2026-09-18',
		completeness: 80,
		blurb: 'A two-hour café, not a day office. Wi-Fi holds for calls until the street power drops; there is no generator.',
		photo: 'riverside'
	},
	{
		slug: 'riverside-annex',
		name: 'Riverside Annex',
		category: 'cafe',
		locationSlug: 'daun-penh',
		wifiMbps: 45,
		hasGenerator: true,
		priceTier: 2,
		verifiedOn: '2026-08-30',
		completeness: 75,
		blurb: 'Quieter upstairs room facing away from the quay. Generator is building-wide, not café-only.',
		photo: 'riverside'
	},
	{
		slug: 'clinic-240',
		name: 'Clinic 240',
		category: 'clinic',
		locationSlug: 'daun-penh',
		wifiMbps: null,
		hasGenerator: true,
		priceTier: 3,
		verifiedOn: '2026-10-11',
		completeness: 85,
		blurb: 'International outpatient clinic. English-speaking reception on weekdays. Confirm specialist hours the morning you go.',
		photo: 'none'
	},
	{
		slug: 'sangkum-lofts',
		name: 'Sangkum Lofts',
		category: 'apartment',
		locationSlug: 'toul-tom-poung',
		wifiMbps: null,
		hasGenerator: true,
		priceTier: 2,
		verifiedOn: '2026-09-04',
		completeness: 70,
		blurb: 'One-bedrooms in a low-rise with a shared generator. Ask which floors the backup actually reaches.',
		photo: 'none'
	},
	{
		slug: 'mekong-visa-desk',
		name: 'Mekong Visa Desk',
		category: 'visa_agent',
		locationSlug: 'daun-penh',
		wifiMbps: null,
		hasGenerator: false,
		priceTier: 2,
		verifiedOn: '2026-10-20',
		completeness: 78,
		blurb: 'Ordinary extension and business-visa paperwork. They do not replace the official fee schedule — compare it before you pay.',
		photo: 'none'
	},
	{
		slug: 'bridge-rooms',
		name: 'Bridge Rooms',
		category: 'coworking',
		locationSlug: 'chroy-changvar',
		wifiMbps: 220,
		hasGenerator: true,
		priceTier: 3,
		verifiedOn: '2026-08-12',
		completeness: 72,
		blurb: 'Fast line and building backup power. The commute across the bridge is the real cost, not the desk.',
		photo: 'cowork'
	},
	{
		slug: 'market-edge-flats',
		name: 'Market Edge Flats',
		category: 'apartment',
		locationSlug: 'bkk1',
		wifiMbps: null,
		hasGenerator: false,
		priceTier: 3,
		verifiedOn: '2026-07-22',
		completeness: 60,
		blurb: 'Furnished one-bedrooms without a generator. Fine if you work elsewhere during outages; poor if you do not.',
		photo: 'none'
	}
];

export const guides: Guide[] = [
	{
		slug: 'first-ninety-days',
		pillar: 'live',
		title: 'The first ninety days of a lease in Phnom Penh',
		dek: 'What to confirm before you transfer a deposit, and what can wait until the second month.',
		author: 'Editorial desk',
		reviewed: '12 October 2026',
		minutes: 8,
		sections: [
			{
				heading: 'Read the power note before the view',
				body: [
					'A one-bedroom price without a generator is not comparable to one with building backup. Ask which floors the generator covers, how long it runs, and whether the elevator is on the same circuit.',
					'If the answer is vague, treat the unit as unpowered during outages and price your coworking days into the rent.'
				]
			},
			{
				heading: 'Deposit, inventory, and the name on the contract',
				body: [
					'Pay the deposit against a written inventory, including air-conditioners and the water heater. Photograph meter readings on the day you receive keys.',
					'The name on the lease should match the person who can return the deposit. If a agent is in the middle, write their role into the document rather than assuming it.'
				]
			},
			{
				heading: 'What can wait',
				body: [
					'Furnishing beyond a bed and a desk can wait. A local SIM and a clinic you have actually walked to should not. Register the address you will use for visa paperwork before you start an extension, not the week it is due.'
				]
			}
		]
	},
	{
		slug: 'generators-and-neighbourhoods',
		pillar: 'live',
		title: 'How generator coverage changes a neighbourhood',
		dek: 'Walkability scores do not capture the afternoon the street power drops.',
		author: 'Editorial desk',
		reviewed: '2 October 2026',
		minutes: 6,
		sections: [
			{
				heading: 'Three different promises',
				body: [
					'A café “with a generator” may mean the espresso machine stays on and the Wi-Fi does not. A coworking floor usually means desks, routers, and air-conditioning. A condo may mean common areas only.',
					'The directory records a single yes or no, plus the verification date. Read the note on the venue before you plan a workday around it.'
				]
			},
			{
				heading: 'Where it matters most',
				body: [
					'BKK1 and Daun Penh have enough backup options that a single outage is an inconvenience. Side streets in Toul Tom Poung and most of Chroy Changvar outside a managed tower are less forgiving.',
					'If your work cannot pause, pick the building first and the street second.'
				]
			}
		]
	},
	{
		slug: 'five-days-without-logistics',
		pillar: 'visit',
		title: 'Five days that do not disappear into logistics',
		dek: 'A short stay organised around neighbourhoods, not a checklist of sights.',
		author: 'Editorial desk',
		reviewed: '28 September 2026',
		minutes: 7,
		sections: [
			{
				heading: 'Stay on one side of the river',
				body: [
					'Unless you have a reason to be in Chroy Changvar, sleep in Daun Penh or BKK1. The bridge is a poor use of a five-day trip.',
					'Book a clinic-adjacent hotel only if someone in the party needs it. Otherwise the riverfront is enough orientation for the first evening.'
				]
			},
			{
				heading: 'Two bases, not five pins',
				body: [
					'Use Daun Penh for the river, the palace-side walks, and any visa errand you cannot avoid. Use BKK1 for meals and a long work block if you are not fully offline.',
					'Russian Market is a morning, not a day. Leave before the heat settles and do not schedule anything that requires punctuality afterwards.'
				]
			},
			{
				heading: 'What to skip',
				body: [
					'Do not spend a day “figuring out SIM cards and cash” if you can do both in an hour on arrival. Do not stack a border run and a day trip. The point of a short visit is one unhurried neighbourhood, not complete coverage.'
				]
			}
		]
	},
	{
		slug: 'arriving-with-a-deadline',
		pillar: 'visit',
		title: 'Arriving when you already have a deadline',
		dek: 'If a visa date or a clinic appointment is the reason for the trip, organise the city around that hour.',
		author: 'Editorial desk',
		reviewed: '15 September 2026',
		minutes: 5,
		sections: [
			{
				heading: 'Put the appointment on the map first',
				body: [
					'Stay in the same sangkat as the office or clinic if the appointment is before 10:00. Traffic across town is not a reliable thirty minutes.',
					'Visa agents in Daun Penh are convenient for the administrative offices and inconvenient for everything else. That trade is worth it for one or two days, not for a week of evenings.'
				]
			},
			{
				heading: 'Paper, then the city',
				body: [
					'Finish the errand on day one or day two. The rest of the stay can be ordinary: one neighbourhood on foot, one long lunch, an early night before a flight.',
					'If the office asks for a document you do not have, you want that discovery on the first morning, not the afternoon before you leave.'
				]
			}
		]
	}
];

export function locationBySlug(slug: string): Location | undefined {
	return locations.find((location) => location.slug === slug);
}

export function guidesByPillar(pillar: Pillar): Guide[] {
	return guides.filter((guide) => guide.pillar === pillar);
}

export function guideBySlug(pillar: Pillar, slug: string): Guide | undefined {
	return guides.find((guide) => guide.pillar === pillar && guide.slug === slug);
}

export function categoryLabel(category: VenueCategory): string {
	return CATEGORIES.find((item) => item.id === category)?.label ?? category;
}

export function tierLabel(tier: number): string {
	return '$'.repeat(tier);
}
