import * as universal from "../../../../frontend/routes/live/[slug]/+page.ts";
export { universal };
export { default as component } from "../../../../frontend/routes/live/[slug]/+page.svelte";