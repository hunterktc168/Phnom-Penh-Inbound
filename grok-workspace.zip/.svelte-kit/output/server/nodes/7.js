import * as universal from '../entries/pages/visit/_slug_/_page.ts.js';

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/visit/_slug_/_page.svelte.js')).default;
export { universal };
export const universal_id = "frontend/routes/visit/[slug]/+page.ts";
export const imports = ["_app/immutable/nodes/7.BejFA09U.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/h2JS-svK.js","_app/immutable/chunks/DgUoRnMe.js","_app/immutable/chunks/Dt-HX3Vu.js"];
export const stylesheets = [];
export const fonts = [];
