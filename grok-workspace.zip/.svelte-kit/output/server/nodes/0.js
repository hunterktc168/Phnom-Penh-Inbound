import * as universal from '../entries/pages/_layout.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { universal };
export const universal_id = "frontend/routes/+layout.ts";
export const imports = ["_app/immutable/nodes/0.BjHYcT3o.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/pAoUochj.js","_app/immutable/chunks/DTLYatpg.js","_app/immutable/chunks/Dt-HX3Vu.js"];
export const stylesheets = ["_app/immutable/assets/0.D8YtLlE5.css"];
export const fonts = [];
