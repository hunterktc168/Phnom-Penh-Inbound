import { i as guidesByPillar } from "../../../../chunks/data.js";
import { error } from "@sveltejs/kit";
//#region frontend/routes/live/[slug]/+page.ts
function entries() {
	return guidesByPillar("live").map((guide) => ({ slug: guide.slug }));
}
var load = ({ params }) => {
	const guide = guidesByPillar("live").find((item) => item.slug === params.slug);
	if (!guide) error(404, "Guide not found");
	return { guide };
};
//#endregion
export { entries, load };
