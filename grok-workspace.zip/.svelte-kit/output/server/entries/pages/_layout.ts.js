//#region frontend/routes/+layout.ts
var prerender = true;
var trailingSlash = "never";
//#endregion
export { prerender, trailingSlash };
