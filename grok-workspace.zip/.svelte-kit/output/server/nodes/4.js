

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/live/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.CektfheX.js","_app/immutable/chunks/Cv046Fgh.js","_app/immutable/chunks/xihTtKlq.js","_app/immutable/chunks/BjpwoQae.js","_app/immutable/chunks/h2JS-svK.js"];
export const stylesheets = [];
export const fonts = [];
