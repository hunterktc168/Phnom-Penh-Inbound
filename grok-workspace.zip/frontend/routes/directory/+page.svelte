<script lang="ts">
	import { browser } from '$app/environment';
	import { afterNavigate } from '$app/navigation';
	import {
		CATEGORIES,
		categoryLabel,
		locationBySlug,
		tierLabel,
		venues,
		type VenueCategory
	} from '$lib/data';

	let category = $state('all');
	let generator = $state(false);

	function readFilters() {
		if (!browser) return;
		const params = new URLSearchParams(window.location.search);
		category = params.get('category') ?? 'all';
		generator = params.get('generator') === 'true';
	}

	afterNavigate(readFilters);

	const filtered = $derived(
		venues.filter((venue) => {
			if (category !== 'all' && venue.category !== category) return false;
			if (generator && !venue.hasGenerator) return false;
			return true;
		})
	);

	function hrefFor(nextCategory: string, nextGenerator: boolean): string {
		const params = new URLSearchParams();
		if (nextCategory !== 'all') params.set('category', nextCategory);
		if (nextGenerator) params.set('generator', 'true');
		const query = params.toString();
		return query ? `/directory?${query}` : '/directory';
	}

	function photo(kind: 'riverside' | 'cowork' | 'none'): string | null {
		if (kind === 'riverside') return '/riverside.jpg';
		if (kind === 'cowork') return '/cowork.jpg';
		return null;
	}
</script>

<svelte:head>
	<title>Directory — Inbound</title>
</svelte:head>

<div class="wrap page-title">
	<p class="kicker">Directory</p>
	<h1>Places that were checked, not scraped.</h1>
	<p class="lede">
		Active listings only: a verification date inside ninety days, and enough detail to be useful. Filter by what you actually need this week.
	</p>
	<div class="filters" role="group" aria-label="Category">
		{#each CATEGORIES as item}
			<a
				class="chip"
				href={hrefFor(item.id, generator)}
				aria-current={category === item.id ? 'true' : undefined}
			>
				{item.label}
			</a>
		{/each}
		<a
			class="chip"
			href={hrefFor(category, !generator)}
			aria-current={generator ? 'true' : undefined}
		>
			Generator
		</a>
	</div>
</div>

<div class="wrap" style="padding-bottom: 56px;">
	{#if filtered.length === 0}
		<p class="empty">Nothing in this cut of the directory. Clear the generator filter or choose another category.</p>
	{:else}
		<div class="venue-list">
			{#each filtered as venue (venue.slug)}
				<article class="venue">
					<div class="venue-photo">
						{#if photo(venue.photo)}
							<img src={photo(venue.photo)} alt="" />
						{/if}
					</div>
					<div class="venue-main">
						<div class="venue-top">
							<div>
								<p class="pill">{categoryLabel(venue.category as VenueCategory)}</p>
								<h2 style="font-size: 28px; margin-top: 4px;">{venue.name}</h2>
							</div>
							<p class="meta">{tierLabel(venue.priceTier)}</p>
						</div>
						<p style="margin-top: 8px;">{venue.blurb}</p>
						<div class="facts">
							<span>{locationBySlug(venue.locationSlug)?.name}</span>
							<span>{venue.hasGenerator ? 'Generator' : 'No generator'}</span>
							{#if venue.wifiMbps}
								<span>{venue.wifiMbps} Mbps checked</span>
							{/if}
							<span>Verified {venue.verifiedOn}</span>
							<span>Completeness {venue.completeness}</span>
						</div>
					</div>
				</article>
			{/each}
		</div>
	{/if}
</div>
