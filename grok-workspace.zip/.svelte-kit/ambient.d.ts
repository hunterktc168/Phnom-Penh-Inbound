
// this file is generated — do not edit it


/// <reference types="@sveltejs/kit" />

/**
 * This module provides access to environment variables that are injected _statically_ into your bundle at build time and are limited to _private_ access.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Static environment variables are [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env` at build time and then statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * **_Private_ access:**
 * 
 * - This module cannot be imported into client-side code
 * - This module only includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured)
 * 
 * For example, given the following build time environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { ENVIRONMENT, PUBLIC_BASE_URL } from '$env/static/private';
 * 
 * console.log(ENVIRONMENT); // => "production"
 * console.log(PUBLIC_BASE_URL); // => throws error during build
 * ```
 * 
 * The above values will be the same _even if_ different values for `ENVIRONMENT` or `PUBLIC_BASE_URL` are set at runtime, as they are statically replaced in your code with their build time values.
 */
declare module '$env/static/private' {
	export const VITE_AUTH_ENABLED: string;
	export const STORYBOOK_HOST: string;
	export const WEBPACK_DEV_SERVER_HOST: string;
	export const X_USER_ID: string;
	export const GROK_WORKSPACE_SESSION_IDLE_PRUNE_SECS: string;
	export const STREAMLIT_SERVER_ADDRESS: string;
	export const NO_UPDATE_NOTIFIER: string;
	export const npm_config_user_agent: string;
	export const AGENT_BROWSER_EXECUTABLE_PATH: string;
	export const GIT_EDITOR: string;
	export const SYSTEMD_PAGER: string;
	export const BINDING: string;
	export const GROK_WORKSPACE_BUNDLED_SKILLS_DIR: string;
	export const HOSTNAME: string;
	export const GROK_WORKSPACE_SERVER_SKILLS_DIR: string;
	export const npm_node_execpath: string;
	export const SHLVL: string;
	export const npm_config_noproxy: string;
	export const GROK_WORKSPACE_HUB_CONNECT_DEADLINE_SECS: string;
	export const HOME: string;
	export const JUPYTER_IP: string;
	export const OLDPWD: string;
	export const NUXT_HOST: string;
	export const npm_package_json: string;
	export const GROK_WORKSPACE_WS_PING_SECS: string;
	export const ENVIRONMENT_ID: string;
	export const GPG_KEY: string;
	export const PAGER: string;
	export const GROK_WORKSPACE_PRESENCE_KEEPALIVE_ENABLED: string;
	export const MC_ASSET_SERVER_FS_ROUTE_TO_MC_ASSETS: string;
	export const npm_config_userconfig: string;
	export const npm_config_local_prefix: string;
	export const PYTHON_SHA256: string;
	export const DO_NOT_TRACK: string;
	export const NO_COLOR: string;
	export const NPM_CONFIG_IGNORE_SCRIPTS: string;
	export const GROK_CLI_CHAT_PROXY_BASE_URL: string;
	export const COLOR: string;
	export const XAI_API_KEY: string;
	export const GROK_WORKSPACE_DATA_COLLECTION_DISABLED: string;
	export const GROK_WORKSPACE_PREVIEW_STATE_REPORTER_ENABLED: string;
	export const GROK_WORKSPACE_PREVIEW_STATE_WAIT_SECS: string;
	export const POLYGON_API_BASE_URL: string;
	export const FORCE_COLOR: string;
	export const GROK_WORKSPACE_PREVIEW_ACTIVITY_SCRAPE_INTERVAL_MS: string;
	export const _: string;
	export const npm_config_prefix: string;
	export const npm_config_npm_version: string;
	export const RUST_LOG: string;
	export const WORKSPACE_DIR: string;
	export const GATSBY_HOST: string;
	export const TERM: string;
	export const npm_config_cache: string;
	export const RUSTUP_HOME: string;
	export const FLASK_RUN_HOST: string;
	export const GROK_WORKSPACE_HUB_CONNECT_HEDGE_AFTER_SECS: string;
	export const APP_TEMPLATE_DIR: string;
	export const npm_config_node_gyp: string;
	export const PATH: string;
	export const GROK_SESSION_ID: string;
	export const VITE_DEV_SERVER_HOST: string;
	export const AWS_PAGER: string;
	export const NODE: string;
	export const npm_package_name: string;
	export const PLAYWRIGHT_BROWSERS_PATH: string;
	export const UVICORN_HOST: string;
	export const GUNICORN_BIND: string;
	export const GROK_WORKSPACE_IDLE_IGNORE_BACKGROUND_TASKS: string;
	export const LANG: string;
	export const TRACEPARENT: string;
	export const GROK_WORKSPACE_SHARED_CHROME: string;
	export const GH_PAGER: string;
	export const MANPAGER: string;
	export const GROK_WORKSPACE_PREVIEW_HOLDS_ENABLED: string;
	export const npm_lifecycle_script: string;
	export const HOST: string;
	export const NODE_PATH: string;
	export const GIT_TERMINAL_PROMPT: string;
	export const npm_lifecycle_event: string;
	export const PYTHON_VERSION: string;
	export const GRADIO_SERVER_NAME: string;
	export const COINGECKO_BASE_URL: string;
	export const NPM_CONFIG_AUDIT: string;
	export const SKIP_FETCH: string;
	export const GROK_WORKSPACE_RPC_ACTIVITY_WINDOW_MS: string;
	export const GROVE_TOKEN_ROTATION: string;
	export const FILES_SERVER_ENDPOINT: string;
	export const GIT_PAGER: string;
	export const npm_config_globalconfig: string;
	export const npm_config_init_module: string;
	export const GROK_AGENT: string;
	export const GPG_TTY: string;
	export const PWD: string;
	export const NPM_CONFIG_FUND: string;
	export const npm_execpath: string;
	export const CARGO_HOME: string;
	export const npm_config_global_prefix: string;
	export const npm_command: string;
	export const GROK_WORKSPACE_PREVIEW_ACTIVITY_WINDOW_MS: string;
	export const GIT_SEQUENCE_EDITOR: string;
	export const TERMINAL_JWT_VAL: string;
	export const GROK_SERVER_KEY: string;
	export const GROK_SANDBOX_PROFILE: string;
	export const SANDBOX_SERVICE_ENV: string;
	export const GROVE_CARRIER_DIR: string;
	export const INIT_CWD: string;
	export const EDITOR: string;
	export const NODE_ENV: string;
}

/**
 * This module provides access to environment variables that are injected _statically_ into your bundle at build time and are _publicly_ accessible.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Static environment variables are [loaded by Vite](https://vitejs.dev/guide/env-and-mode.html#env-files) from `.env` files and `process.env` at build time and then statically injected into your bundle at build time, enabling optimisations like dead code elimination.
 * 
 * **_Public_ access:**
 * 
 * - This module _can_ be imported into client-side code
 * - **Only** variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`) are included
 * 
 * For example, given the following build time environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { ENVIRONMENT, PUBLIC_BASE_URL } from '$env/static/public';
 * 
 * console.log(ENVIRONMENT); // => throws error during build
 * console.log(PUBLIC_BASE_URL); // => "http://site.com"
 * ```
 * 
 * The above values will be the same _even if_ different values for `ENVIRONMENT` or `PUBLIC_BASE_URL` are set at runtime, as they are statically replaced in your code with their build time values.
 */
declare module '$env/static/public' {
	
}

/**
 * This module provides access to environment variables set _dynamically_ at runtime and that are limited to _private_ access.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Dynamic environment variables are defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`.
 * 
 * **_Private_ access:**
 * 
 * - This module cannot be imported into client-side code
 * - This module includes variables that _do not_ begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) _and do_ start with [`config.kit.env.privatePrefix`](https://svelte.dev/docs/kit/configuration#env) (if configured)
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 * 
 * > [!NOTE] To get correct types, environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * >
 * > ```env
 * > MY_FEATURE_FLAG=
 * > ```
 * >
 * > You can override `.env` values from the command line like so:
 * >
 * > ```sh
 * > MY_FEATURE_FLAG="enabled" npm run dev
 * > ```
 * 
 * For example, given the following runtime environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://site.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { env } from '$env/dynamic/private';
 * 
 * console.log(env.ENVIRONMENT); // => "production"
 * console.log(env.PUBLIC_BASE_URL); // => undefined
 * ```
 */
declare module '$env/dynamic/private' {
	export const env: {
		VITE_AUTH_ENABLED: string;
		STORYBOOK_HOST: string;
		WEBPACK_DEV_SERVER_HOST: string;
		X_USER_ID: string;
		GROK_WORKSPACE_SESSION_IDLE_PRUNE_SECS: string;
		STREAMLIT_SERVER_ADDRESS: string;
		NO_UPDATE_NOTIFIER: string;
		npm_config_user_agent: string;
		AGENT_BROWSER_EXECUTABLE_PATH: string;
		GIT_EDITOR: string;
		SYSTEMD_PAGER: string;
		BINDING: string;
		GROK_WORKSPACE_BUNDLED_SKILLS_DIR: string;
		HOSTNAME: string;
		GROK_WORKSPACE_SERVER_SKILLS_DIR: string;
		npm_node_execpath: string;
		SHLVL: string;
		npm_config_noproxy: string;
		GROK_WORKSPACE_HUB_CONNECT_DEADLINE_SECS: string;
		HOME: string;
		JUPYTER_IP: string;
		OLDPWD: string;
		NUXT_HOST: string;
		npm_package_json: string;
		GROK_WORKSPACE_WS_PING_SECS: string;
		ENVIRONMENT_ID: string;
		GPG_KEY: string;
		PAGER: string;
		GROK_WORKSPACE_PRESENCE_KEEPALIVE_ENABLED: string;
		MC_ASSET_SERVER_FS_ROUTE_TO_MC_ASSETS: string;
		npm_config_userconfig: string;
		npm_config_local_prefix: string;
		PYTHON_SHA256: string;
		DO_NOT_TRACK: string;
		NO_COLOR: string;
		NPM_CONFIG_IGNORE_SCRIPTS: string;
		GROK_CLI_CHAT_PROXY_BASE_URL: string;
		COLOR: string;
		XAI_API_KEY: string;
		GROK_WORKSPACE_DATA_COLLECTION_DISABLED: string;
		GROK_WORKSPACE_PREVIEW_STATE_REPORTER_ENABLED: string;
		GROK_WORKSPACE_PREVIEW_STATE_WAIT_SECS: string;
		POLYGON_API_BASE_URL: string;
		FORCE_COLOR: string;
		GROK_WORKSPACE_PREVIEW_ACTIVITY_SCRAPE_INTERVAL_MS: string;
		_: string;
		npm_config_prefix: string;
		npm_config_npm_version: string;
		RUST_LOG: string;
		WORKSPACE_DIR: string;
		GATSBY_HOST: string;
		TERM: string;
		npm_config_cache: string;
		RUSTUP_HOME: string;
		FLASK_RUN_HOST: string;
		GROK_WORKSPACE_HUB_CONNECT_HEDGE_AFTER_SECS: string;
		APP_TEMPLATE_DIR: string;
		npm_config_node_gyp: string;
		PATH: string;
		GROK_SESSION_ID: string;
		VITE_DEV_SERVER_HOST: string;
		AWS_PAGER: string;
		NODE: string;
		npm_package_name: string;
		PLAYWRIGHT_BROWSERS_PATH: string;
		UVICORN_HOST: string;
		GUNICORN_BIND: string;
		GROK_WORKSPACE_IDLE_IGNORE_BACKGROUND_TASKS: string;
		LANG: string;
		TRACEPARENT: string;
		GROK_WORKSPACE_SHARED_CHROME: string;
		GH_PAGER: string;
		MANPAGER: string;
		GROK_WORKSPACE_PREVIEW_HOLDS_ENABLED: string;
		npm_lifecycle_script: string;
		HOST: string;
		NODE_PATH: string;
		GIT_TERMINAL_PROMPT: string;
		npm_lifecycle_event: string;
		PYTHON_VERSION: string;
		GRADIO_SERVER_NAME: string;
		COINGECKO_BASE_URL: string;
		NPM_CONFIG_AUDIT: string;
		SKIP_FETCH: string;
		GROK_WORKSPACE_RPC_ACTIVITY_WINDOW_MS: string;
		GROVE_TOKEN_ROTATION: string;
		FILES_SERVER_ENDPOINT: string;
		GIT_PAGER: string;
		npm_config_globalconfig: string;
		npm_config_init_module: string;
		GROK_AGENT: string;
		GPG_TTY: string;
		PWD: string;
		NPM_CONFIG_FUND: string;
		npm_execpath: string;
		CARGO_HOME: string;
		npm_config_global_prefix: string;
		npm_command: string;
		GROK_WORKSPACE_PREVIEW_ACTIVITY_WINDOW_MS: string;
		GIT_SEQUENCE_EDITOR: string;
		TERMINAL_JWT_VAL: string;
		GROK_SERVER_KEY: string;
		GROK_SANDBOX_PROFILE: string;
		SANDBOX_SERVICE_ENV: string;
		GROVE_CARRIER_DIR: string;
		INIT_CWD: string;
		EDITOR: string;
		NODE_ENV: string;
		[key: `PUBLIC_${string}`]: undefined;
		[key: `${string}`]: string | undefined;
	}
}

/**
 * This module provides access to environment variables set _dynamically_ at runtime and that are _publicly_ accessible.
 * 
 * |         | Runtime                                                                    | Build time                                                               |
 * | ------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
 * | Private | [`$env/dynamic/private`](https://svelte.dev/docs/kit/$env-dynamic-private) | [`$env/static/private`](https://svelte.dev/docs/kit/$env-static-private) |
 * | Public  | [`$env/dynamic/public`](https://svelte.dev/docs/kit/$env-dynamic-public)   | [`$env/static/public`](https://svelte.dev/docs/kit/$env-static-public)   |
 * 
 * Dynamic environment variables are defined by the platform you're running on. For example if you're using [`adapter-node`](https://github.com/sveltejs/kit/tree/main/packages/adapter-node) (or running [`vite preview`](https://svelte.dev/docs/kit/cli)), this is equivalent to `process.env`.
 * 
 * **_Public_ access:**
 * 
 * - This module _can_ be imported into client-side code
 * - **Only** variables that begin with [`config.kit.env.publicPrefix`](https://svelte.dev/docs/kit/configuration#env) (which defaults to `PUBLIC_`) are included
 * 
 * > [!NOTE] In `dev`, `$env/dynamic` includes environment variables from `.env`. In `prod`, this behavior will depend on your adapter.
 * 
 * > [!NOTE] To get correct types, environment variables referenced in your code should be declared (for example in an `.env` file), even if they don't have a value until the app is deployed:
 * >
 * > ```env
 * > MY_FEATURE_FLAG=
 * > ```
 * >
 * > You can override `.env` values from the command line like so:
 * >
 * > ```sh
 * > MY_FEATURE_FLAG="enabled" npm run dev
 * > ```
 * 
 * For example, given the following runtime environment:
 * 
 * ```env
 * ENVIRONMENT=production
 * PUBLIC_BASE_URL=http://example.com
 * ```
 * 
 * With the default `publicPrefix` and `privatePrefix`:
 * 
 * ```ts
 * import { env } from '$env/dynamic/public';
 * console.log(env.ENVIRONMENT); // => undefined, not public
 * console.log(env.PUBLIC_BASE_URL); // => "http://example.com"
 * ```
 * 
 * ```
 * 
 * ```
 */
declare module '$env/dynamic/public' {
	export const env: {
		[key: `PUBLIC_${string}`]: string | undefined;
	}
}
